package com.cap.maven.WelcomeApp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
	
public static void main(String[] args) {
	ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
	Object obj=context.getBean(Employee.class);
	Employee emp=(Employee) obj;
	emp.setEid(123);
	emp.setEname("shubham");
	System.out.println(emp);
}
	

}
