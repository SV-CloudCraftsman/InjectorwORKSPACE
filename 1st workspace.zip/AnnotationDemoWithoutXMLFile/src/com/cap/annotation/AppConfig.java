package com.cap.annotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	@Bean("getEmp")
	public Employee getEmployee()
	{
		return new Employee();
	}
	
	

}
