import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

public class Test {
	public static void main(String[] args) {
		
	Client c=Client.create();
	WebResource res=c.resource("http://localhost:2345/JAX_RS_JERSEY_SERVICES/rest/welcomeService/xyz/shubham/22");
	String res1=res.get(String.class);
	System.out.println(res1);
	}
	
}
