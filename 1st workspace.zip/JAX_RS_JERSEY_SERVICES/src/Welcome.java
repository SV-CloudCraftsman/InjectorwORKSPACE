
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

@Path("/welcomeService")
public class Welcome {
	
	@GET
	@Path("/xyz/{name1}/{age1}")
	public String display(@PathParam("name1") String name, @PathParam("age1") int age)
	{
		return "welcome mr: "+name+ " your age is "+age;
	}
	
	@GET
	@Path("/xyz1/")
	public String display1(@QueryParam("name1") String name, @QueryParam("age1") int age)
	{
		return "welcome mr: "+name+ " your age is "+age;
	}
	
}
