
public class Student {
	private int stuId;
	private String stuName;
	private String stuMarks;
	public int getStuId() {
		return stuId;
	}
	public void setStuId(int stuId) {
		this.stuId = stuId;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getStuMarks() {
		return stuMarks;
	}
	public void setStuMarks(String stuMarks) {
		this.stuMarks = stuMarks;
	}
	@Override
	public String toString() {
		return "Student [stuId=" + stuId + ", stuName=" + stuName + ", stuMarks=" + stuMarks + "]";
	}
	public Student(int stuId, String stuName, String stuMarks) {
		super();
		this.stuId = stuId;
		this.stuName = stuName;
		this.stuMarks = stuMarks;
	}
	
	public Student() {
		// TODO Auto-generated constructor stub
	}
	

}
