import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Employee {
	
	private int eid;
	private String ename;
	private List add;
	private Map<String,String> addr;
	
	
	
	
	public Map<String, String> getAddr() {
		return addr;
	}
	public void setAddr(Map<String, String> addr) {
		this.addr = addr;
	}
	public List getAdd() {
		return add;
	}
	public void setAdd(List add) {
		this.add = add;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	
	public void Display()
	{
		System.out.println(eid+" "+ename);
		Iterator itr=add.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next()+" ");
			
		}
		
		Set s=addr.entrySet();
		Iterator itr1=s.iterator();
		while (itr1.hasNext()) {
			System.out.println(itr1.next());
			
		}
		
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}
}
