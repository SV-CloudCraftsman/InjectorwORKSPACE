import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	
	private int eid;
	private String ename;
	private Address add;

	
	
	@Autowired
	public Employee(int eid, String ename, Address add) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.add = add;
	}


	public void Display()
	{
		System.out.println(eid+" "+ename);
		System.out.println(add);
	}
	

	public Employee() {
		// TODO Auto-generated constructor stub
	}
}
