
public class Address {
	private int hno;
	private String colony;
	private String city;


	public Address(int hno, String colony, String city) {
		super();
		this.hno = hno;
		this.colony = colony;
		this.city = city;
	}


	@Override
	public String toString() {
		return "Address [hno=" + hno + ", colony=" + colony + ", city=" + city + "]";
	}
	
	
	

}
