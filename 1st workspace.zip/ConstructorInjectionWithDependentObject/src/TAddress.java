
public class TAddress {

	private int hno;
	private String colony;
	private String city;

	
	
	public TAddress(int hno, String colony, String city) {
		super();
		this.hno = hno;
		this.colony = colony;
		this.city = city;
	}



	public String toString() {
		return "Address [hno=" + hno + ", colony=" + colony + ", city=" + city + "]";
	}
	
	public TAddress() {
		// TODO Auto-generated constructor stub
	}
	
}
