
public class Employee {
	
	private int eid;
	private String ename;
	private Address add;
	private TAddress address;
	
	
	

	public Employee(int eid, String ename, Address add, TAddress address) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.add = add;
		this.address = address;
	}





	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", add=" + add + ", address=" + address + "]";
	}





	public Employee() {
		// TODO Auto-generated constructor stub
	}
}
