package com.cap.spring;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("empobj")
public class Employee {
	private int eid;
	private String ename;
	@Autowired
	private Address add;
	
	
	public Address getAdd() {
		return add;
	}
	public void setAdd(Address add) {
		this.add = add;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	public void display()
	{
		add.setHno(21);
		add.setColony("jankpuram");
		add.setCity("lko");
		System.out.println("Employee [eid=" + eid + ", ename=" + ename);
		System.out.println(add);
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}
}
